<?php
$servername = "localhost";
$username = "root";
$password = "bnice2me96";

// Create connection
$conn = new mysqli($servername, $username, $password);
// Check connection
global $pokemon_name;
global $dex_no;
if ($conn->connect_error) {
    die("Connection failed: " . $conn->connect_error);
}

//echo "<br>Successful<br>";
mysqli_select_db($conn,"Pokemon");
$sql="SELECT * FROM Pokemon_info";
$result = $conn->query($sql);
$i=1;
if ($result->num_rows > 0) {
    // output data of each row
    while($row = $result->fetch_assoc()) {
     $pokemon_name[$i] = $row["Pokemon_name"];
     $dex_no[$i] = $row["dex_no"];
     $classification[$i] = $row["Classification"];
     $type[$i] = $row["Type"];
     $weight[$i] = $row["weight"];
     $height[$i] = $row["height"];
     $male_ratio[$i] = $row["male_ratio"];
     $capture_rate[$i++] = $row["capture_rate"];

    }
  //  print_r($pokemon_name);
} else {
    echo "0 results";
}
?>
