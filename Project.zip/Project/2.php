<html>
  <head>
    <title>Pokemon World : Pokemon</title>
  </head>
  <link rel="stylesheet" type="text/css" href="style.css">
  <body id="comb">
    <div class="sidebar" id="mySidenav">
      <a href="javascript:void(0)" onclick="closeNav()">
        <img src="close.png" width="28" height="28" id="closing">
      </a>
      <br>
      <br>
      <nav>
      <ul id="sidebar_text">
        <li><img src="pokeball1.png" height="35" width="35"></li>
        <li>Welcome<br>to the world of<br>Pokemon</li>
        <hr>
        <li><a href="javascript:void(0)" onclick="color_changer()">
          <div class="square_round">
          <img src="color_changer.png" width="43" height="50">
        </div>
        </a></li>
        <li>This will change the<br>color of the<br>background on<br> item hover</li>
        <hr>
        <li><a href="game2.php">
          <div class="square_round">
          <img src="wtp.png" width="50" height="50">
        </div>
        </a></li>
        <li>The whose that<br>Pokemon Game</li>
        <hr>
      </ul>
</nav>
    </div>
    <div class= "search"><input type="text" id = "pokesearch" class="seright1">
      <a href="javascript:void(0)">
      <img src ="Unknown.png" class="seright" width="28" height="50" onclick="searching()">
    </a>
      <a href="index.html">
      <img src ="home.png" class="hleft" width="28" height="28"></a>
      <a href="javascript:void(0)"><img src ="all_apps.png" id="aaleft" width="28" height="28" onclick="openNav()"></a>
    </div>
    <br>
    <a href="javascript:void(0)" id="arrows">
    <img src="Navigation/left arrow 0.png" id="light-left" height="120" width="82">
    <img src="Navigation/left arrow.png" id="dark-left" onclick="move_left()" height="120" width="82">
    <img src="Navigation/right arrow 0.png" id="light-right"  height="120" width="82">
    <img src="Navigation/right arrow.png" id="dark-right" onclick="move_right()" height="120" width="82">
  </a>
<br>
<span class="dot" id ="dot0"></span>&nbsp&nbsp
<span class="dot" id = "dot1"></span>&nbsp&nbsp
<span class="dot" id ="dot2"></span>&nbsp&nbsp
<span class="dot" id ="dot3"></span>&nbsp&nbsp
<span class="dot" id ="dot4"></span>&nbsp&nbsp
<span class="dot" id ="dot5"></span>&nbsp&nbsp
<span class="dot" id ="dot6"></span>&nbsp&nbsp
<span class="dot" id ="dot7"></span>&nbsp&nbsp
<span class="dot" id ="dot8"></span>&nbsp&nbsp
<span class="dot" id ="dot9"></span>&nbsp&nbsp
<span class="dot" id ="dot10"></span>&nbsp&nbsp
<span class="dot" id ="dot11"></span>&nbsp&nbsp
<span class="dot" id ="dot12"></span>&nbsp&nbsp
<span class="dot" id ="dot13"></span>&nbsp&nbsp
<span class="dot" id ="dot14"></span>&nbsp&nbsp
<span class="dot" id ="dot15"></span>&nbsp&nbsp
<span class="dot" id ="dot16"></span>&nbsp&nbsp
<span class="dot" id ="dot17"></span>&nbsp&nbsp
<span class="dot" id ="dot18"></span>&nbsp&nbsp
<span class="dot" id ="dot19"></span>&nbsp&nbsp
<span class="dot" id ="dot20"></span>&nbsp&nbsp
<span class="dot" id ="dot21"></span>&nbsp&nbsp
<span class="dot" id ="dot22"></span>&nbsp&nbsp
<span class="dot" id ="dot23"></span>&nbsp&nbsp
<span class="dot" id ="dot24"></span>&nbsp&nbsp
<span class="dot" id ="dot25"></span>&nbsp&nbsp
<div class="sidebar2" id="mySidenav2">
  <a href="javascript:void(0)" onclick="closeNav2()">
    <img src="close.png" width="28" height="28" id="closing2">
  </a>
  <br>
  <br>
  <nav>
  <ul id="sidebar_text2">
  </ul>
</nav>
</div>
<?php
  include 'x.php';
  mysqli_close($conn);
  ?>
   </body>
<script>
  //Adding Database interaction here
   var js_pokemon_name = <? echo json_encode($pokemon_name)?>;
   var js_dex_no = <? echo json_encode($dex_no)?>;
   var js_classification = <? echo json_encode($classification)?>;
   var js_type = <? echo json_encode($type)?>;
   var js_weight = <? echo json_encode($weight)?>;
   var js_height = <? echo json_encode($height)?>;
   var js_male_ratio = <? echo json_encode($male_ratio)?>;
   var js_capture_rate = <? echo json_encode($capture_rate)?>;
   </script>
   <script src ="script.js">
   </script>
</html>
