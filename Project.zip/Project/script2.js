//Adding an extra insert After function
function insertAfter(newNode, referenceNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
}
colc_flag = 0;
//Brings a random image to the page
function imgCall() {
    var num = Math.floor(Math.random() * 150);
    var imgx = document.createElement("img");
    var x = document.getElementById("solution");
    imgx.src = "Pokemon/" + js_dex_no[num + 1] + ".png";
    imgx.height = "190";
    imgx.height = "190";
    imgx.style.position = "absolute";
    imgx.style.left = "70";
    imgx.style.top = "250";
    imgx.style.filter = "brightness(0%)";
    imgx.style.transition = "all 0.75s ease-in-out";
    imgx.id = "imgx"
    imgx.draggable="false";
    var y = document.getElementById("refer1");
    y.parentNode.insertBefore(imgx, y);
}
imgCall();
//Checks Answer and reveals the image on second click removes the image and reloads
function checkAnswer() {
    var n = document.getElementById("imgx");
    var x = document.getElementById("solution");
    if (colc_flag == 0) {
        var num2 = Number(n.src.slice(-7, -4));
        if (js_pokemon_name[num2] == x.value) {
            imgx.style.filter = "brightness(100%)";
            var res = document.createElement("img");
            res.src = "wtp/win.gif";
            res.height = "600";
            res.width = "1200";
            res.id = "result"
            n.parentNode.appendChild(res);
        } else {
            //  imgx.style.filter="brightness(100%)";
            imgx.style.filter = "brightness(100%)";
            var res = document.createElement("img");
            res.src = "wtp/lose.gif";
            res.height = "600";
            res.width = "1200";
            res.id = "result"
            n.parentNode.appendChild(res);
        }
        colc_flag = 1;
    } else {
        var res = document.getElementById("result");
        var m = n.parentNode;
        x.value = "";
        m.removeChild(n);
        m.removeChild(res);
        colc_flag = 0;
        imgCall();
    }
}
//Onlclick open sidebar
function openNav() {
    document.getElementById("sidebar_text").style.visibility = "visible";
    document.getElementById("sidebar_text").style.transitionDelay = "0.75s";
    document.getElementById("sidebar_text").style.opacity = "1";
    document.getElementById("mySidenav").style.width = "200px";
}
//Onlclick close sidebar
function closeNav() {
    document.getElementById("sidebar_text").style.transitionDelay = "0s";
    document.getElementById("sidebar_text").style.visibility = "hidden";
    document.getElementById("sidebar_text").style.opacity = "0";
    document.getElementById("mySidenav").style.width = "0";
}
//Keypress shortcuts
window.addEventListener("keydown", key_function, false);

function key_function(e) {
    var keyCode = e.which;
    if (keyCode == 13) {
        checkAnswer();
    }
}
