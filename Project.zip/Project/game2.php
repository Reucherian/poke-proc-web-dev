<html>
<head>
  <title>Guess the Pokemon</title>
</head>
<body id="background2">
  <link rel="stylesheet" type="text/css" href="style.css">
  <div class="sidebar" id="mySidenav">
    <a href="javascript:void(0)" onclick="closeNav()">
      <img src="close.png" width="28" height="28" id="closing">
    </a>
    <br>
    <br>
    <nav>
    <ul id="sidebar_text">
      <li><img src="pokeball1.png" height="35" width="35"></li>
      <li>Welcome<br>to the Who's that<br>Pokemon Game</li>
      <hr>
    </ul>
</nav>
  </div>
<div class= "search"><input type="text" id = "pokesearch" class="seright1">
  <a href="2.php">
  <img src ="back.png" class="hleft" width="28" height="28"></a>
  <a href="javascript:void(0)"><img src ="all_apps.png" id="aaleft" width="28" height="28" onclick="openNav()"></a>
</div>
  <br id="refer1">
  <img src="wtp/wtp.png" id="wtp" width="562" height="436">
  <input type="textbox" name="answer" id="solution" autocomplete="off" spellcheck="false"
  style="height:60px; width: 350px; font-family:PokemonFont2;font-size:35;border-radius:15; text-align:center;">
    &nbsp&nbsp&nbsp&nbsp
  <a href="javascript:void(0)" id="solution2">
  <img src="Navigation/front.png" height="200" width="200"  onclick="checkAnswer()" align="center">
  </a>
<?php
  include 'x.php';
  mysqli_close($conn);
?>
<script>
  //Adding Database interaction here
   var js_pokemon_name = <? echo json_encode($pokemon_name)?>;
   var js_dex_no = <? echo json_encode($dex_no)?>;
   var js_classification = <? echo json_encode($classification)?>;
   var js_type = <? echo json_encode($type)?>;
   var js_weight = <? echo json_encode($weight)?>;
   var js_height = <? echo json_encode($height)?>;
   var js_male_ratio = <? echo json_encode($male_ratio)?>;
   var js_capture_rate = <? echo json_encode($capture_rate)?>;
   </script>
   <script src ="script2.js">
   </script>
 </body>
</html>
