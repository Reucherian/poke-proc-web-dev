//Database was added in the 2.php part
//Ending Database part here
//Addng an insertAfter function
function insertAfter(newNode, referenceNode) {
    referenceNode.parentNode.insertBefore(newNode, referenceNode.nextSibling);
}
//Inserting all tables dynamically
var rows = 2;
var cols = 2;
var tables_id = 0;
var new_i = document.getElementById("arrows");
for (i = 1; i < 157; i++) {
    if (rows == 2 && cols == 2) {
        var t = document.createElement("table");
        var r = document.createElement("tr");
        t.align = "center";
        t.id = "table" + tables_id++;
        console.log(new_i);
        insertAfter(t, new_i);
        var new_i = document.getElementById("table" + (tables_id - 1));
        new_i.appendChild(r);
        rows = 0;
        cols = 0;
    } else if (cols == 2) {
        var r = document.createElement("tr");
        new_i.appendChild(r);
        rows++;
        cols = 0;
    }
    var c = document.createElement("td");
    if (i < 152) {
        c.className = "pimage";
        var imgx = document.createElement("img");
        imgx.src = "Pokemon/" + js_dex_no[i] + ".png";
        imgx.width = "120";
        imgx.height = "120";
        c.innerHTML = "&nbsp&nbsp&nbsp&nbsp&nbsp";
        c.appendChild(imgx);
        c.onclick = function() {
            sidebar2(this);
        }
    }
    c.height = 200;
    c.width = 360;
    r.appendChild(c);
    cols++;
}
//Ended inserting all things dynamically
//Default settings applied to the page
var colc_flag = 1;
var x = [26];
for (i = 0; i <= 25; i++) {
    x[i] = document.getElementById("table" + i);
    if(i==0){
      x[i].style.display="";
    }
    else{
      x[i].style.display="none";
    }
}
var f = document.getElementById("dot0");
f.style.transform = "scale(1.5,1.5)";
//Ending of the default settings applied to the page
//Code for the onclick Navigation arrows
function move_left() {
    var a = 0;
    while (a <= x.length - 1) {
        if (x[a].style.display != "none") {
            if (a == 0) {} else {
                var i_dot = document.getElementById("dot" + a);
                i_dot.style.transform = "scale(1,1)";
                var f_dot = document.getElementById("dot" + (a - 1));
                f_dot.style.transform = "scale(1.5,1.5)";
                f_dot.color = "#8999A6";
                x[a - 1].style.display = "";
                x[a].style.display = "none";
                return;
            }
        }
        a++;
    }
}

function move_right() {
    var a = 0;
    while (a <= x.length - 1) {
        if (x[a].style.display != "none") {
            if (a == x.length - 1) {} else {
                var i_dot = document.getElementById("dot" + a);
                i_dot.style.transform = "scale(1,1)";
                var f_dot = document.getElementById("dot" + (a + 1));
                f_dot.style.transform = "scale(1.5,1.5)";
                f_dot.color = "#8999A6";
                x[a + 1].style.display = "";
                x[a].style.display = "none";
                return;
            }
        }
        a++;
    }
}
//Ending of the code for the onclick Navigation arrows
//Code for using arrow keys instead of Nav arrows
window.addEventListener("keydown", key_function, false);

function key_function(e) {
    var keyCode = e.which;
    if (keyCode == 37) {
        move_left();
    }
    if (keyCode == 39) {
        move_right();
    }
    if (e.altKey) {
        if (keyCode == 83) {
            searching();
        }
    }
}
//Beginning of the code for search box
function searching() {
    var m = document.getElementById("pokesearch");
    if (m.style.opacity != 1) {
        m.spellcheck="false";
        m.autocomplete="off";
        m.style.visibility = "visible";
        m.style.opacity = 1;
    } else {
      if(m.value == ""){}
      else{
        var ss = new RegExp(m.value);
        for(i=1;i<=151;i++){
        if (ss.test(js_pokemon_name[i])){
          var new_ss = document.getElementsByClassName("pimage");
          sidebar2(new_ss[i-1]);
          break;
        }
        }
      }
        m.style.visibility = "hidden";
        m.style.opacity = 0;
    }
    m.value = "";
}
//Ending of code for search box
//Code for the color changer
function color_changer() {
    if (colc_flag == 0) {
        colc_flag = 1;
    } else {
        colc_flag = 0;
    }
}
//Ending code for the search box
//Onlclick open sidebar
function openNav() {
    document.getElementById("sidebar_text").style.visibility = "visible";
    document.getElementById("sidebar_text").style.transitionDelay = "0.75s";
    document.getElementById("sidebar_text").style.opacity = "1";
    document.getElementById("mySidenav").style.width = "200px";
}
//Onlclick close sidebar
function closeNav() {
    document.getElementById("sidebar_text").style.transitionDelay = "0s";
    document.getElementById("sidebar_text").style.visibility = "hidden";
    document.getElementById("sidebar_text").style.opacity = "0";
    document.getElementById("mySidenav").style.width = "0";
}
//Changing the text and type according to the image src
var table_data = document.getElementsByClassName("pimage");
for (i = 0; i < table_data.length; i++) {
    for (j = 1; j < 152; j++) {
        if (((table_data[i].childNodes[1]).src.slice(-7, -4)) == js_dex_no[j]) {
            var para = document.createElement("p");
            var textnode = document.createTextNode("#" + js_dex_no[j] + "\n" + js_pokemon_name[j]);
            para.appendChild(textnode);
            para.className = "Poke_Text";
            if (js_type[j] == "Grass,Poison") {
                table_data[i].className += " grass";
            }
            if (js_type[j] == "Fire") {
                table_data[i].className += " fire";
            }
            if (js_type[j] == "Fire,Fly") {
                table_data[i].className += " fire";
            }
            if (js_type[j] == "Water") {
                table_data[i].className += " water";
            }
            if (js_type[j] == "Bug") {
                table_data[i].className += " bug";
            }
            if (js_type[j] == "Bug,Flying") {
                table_data[i].className += " bug";
            }
            if (js_type[j] == "Bug,Poison") {
                table_data[i].className += " bug";
            }
            if (js_type[j] == "Normal,Flying") {
                table_data[i].className += " normal";
            }
            if (js_type[j] == "Normal") {
                table_data[i].className += " normal";
            }
            if (js_type[j] == "Poison") {
                table_data[i].className += " poison";
            }
            if (js_type[j] == "Electr") {
                table_data[i].className += " electr";
            }
            if (js_type[j] == "Ground") {
                table_data[i].className += " ground";
            }
            if (js_type[j] == "Poison,Ground") {
                table_data[i].className += " poison";
            }
            if (js_type[j] == "Fairy") {
                table_data[i].className += " fairy";
            }
            if (js_type[j] == "Normal,Fairy") {
                table_data[i].className += " normal";
            }
            if (js_type[j] == "Poison,Flying") {
                table_data[i].className += " poison";
            }
            if (js_type[j] == "Poison,Grass") {
                table_data[i].className += " poison";
            }
            if (js_type[j] == "Bug,Grass") {
                table_data[i].className += " bug";
            }
            if (js_type[j] == "Poison,Bug") {
                table_data[i].className += " poison";
            }
            if (js_type[j] == "Fight") {
                table_data[i].className += " fight";
            }
            if (js_type[j] == "Water,Fight") {
                table_data[i].className += " water";
            }
            if (js_type[j] == "Psychc") {
                table_data[i].className += " psychc";
            }
            if (js_type[j] == "Water,Poison") {
                table_data[i].className += " water";
            }
            if (js_type[j] == "Rock,Ground") {
                table_data[i].className += " rock";
            }
            if (js_type[j] == "Water,Psychc") {
                table_data[i].className += " water";
            }
            if (js_type[j] == "Electr,Steel") {
                table_data[i].className += " electr";
            }
            if (js_type[j] == "Water,Ice") {
                table_data[i].className += " water";
            }
            if (js_type[j] == "Ghost,Poison") {
                table_data[i].className += " ghost";
            }
            if (js_type[j] == "Grass,Psychc") {
                table_data[i].className += " grass";
            }
            if (js_type[j] == "Ground,Rock") {
                table_data[i].className += " ground";
            }
            if (js_type[j] == "Grass") {
                table_data[i].className += " grass";
            }
            if (js_type[j] == "Psychc,Fairy") {
                table_data[i].className += " psychc";
            }
            if (js_type[j] == "Ice,Psychc") {
                table_data[i].className += " ice";
            }
            if (js_type[j] == "Water,Flying") {
                table_data[i].className += " water";
            }
            if (js_type[j] == "Rock,Water") {
                table_data[i].className += " rock";
            }
            if (js_type[j] == "Rock,Flying") {
                table_data[i].className += " rock";
            }
            if (js_type[j] == "Ice,Flying") {
                table_data[i].className += " ice";
            }
            if (js_type[j] == "Electr,Flying") {
                table_data[i].className += " electr";
            }
            if (js_type[j] == "Fire,Flying") {
                table_data[i].className += " fire";
            }
            if (js_type[j] == "Dragon") {
                table_data[i].className += " dragon";
            }
            if (js_type[j] == "Dragon,Flying") {
                table_data[i].className += " dragon";
            }
            table_data[i].appendChild(para);

        }
    }
}
//All colors text have been set
//Setting different background colors for different types
var grass = document.getElementsByClassName('grass');
for (i = 0; i < grass.length; i++) {
    grass[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#c8f8c3";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    grass[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var fire = document.getElementsByClassName('fire');
for (i = 0; i < fire.length; i++) {
    fire[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#ffd0ae";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    fire[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var water = document.getElementsByClassName('water');
for (i = 0; i < water.length; i++) {
    water[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#bcddfe";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    water[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var bug = document.getElementsByClassName('bug');
for (i = 0; i < bug.length; i++) {
    bug[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#ffffb7";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    bug[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var normal = document.getElementsByClassName('normal');
for (i = 0; i < normal.length; i++) {
    normal[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#f2d0ab";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    normal[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var poison = document.getElementsByClassName('poison');
for (i = 0; i < poison.length; i++) {
    poison[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#cdbdef";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    poison[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var electr = document.getElementsByClassName('electr');
for (i = 0; i < electr.length; i++) {
    electr[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#fffcc6";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    electr[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var ground = document.getElementsByClassName('ground');
for (i = 0; i < ground.length; i++) {
    ground[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#e2dbb5";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    ground[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var fairy = document.getElementsByClassName('fairy');
for (i = 0; i < fairy.length; i++) {
    fairy[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#efcbed";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    fairy[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var fight = document.getElementsByClassName('fight');
for (i = 0; i < fight.length; i++) {
    fight[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#ffafaf";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    fight[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var rock = document.getElementsByClassName('rock');
for (i = 0; i < rock.length; i++) {
    rock[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#d6c493";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    rock[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var ghost = document.getElementsByClassName('ghost');
for (i = 0; i < ghost.length; i++) {
    ghost[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#948fa8";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    ghost[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var psychc = document.getElementsByClassName('psychc');
for (i = 0; i < psychc.length; i++) {
    psychc[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#dba8d3";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    psychc[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var ice = document.getElementsByClassName('ice');
for (i = 0; i < ice.length; i++) {
    ice[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#d3f4ff";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    ice[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}
var dragon = document.getElementsByClassName('dragon');
for (i = 0; i < dragon.length; i++) {
    dragon[i].addEventListener("mouseenter", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "#bcc0ff";
            document.getElementById("comb").style.transition = " all 0.75s ease-in-out";
        }
    })
    dragon[i].addEventListener("mouseleave", function() {
        if (colc_flag == 1) {
            document.getElementById("comb").style.background = "white";
        }
    })
}

//Background colors have been set
//Onlclick open sidebar2
function sidebar2(param) {
    document.getElementById("sidebar_text2").style.visibility = "visible";
    document.getElementById("sidebar_text2").style.transitionDelay = "0.75s";
    document.getElementById("sidebar_text2").style.opacity = "1";
    document.getElementById("mySidenav2").style.height = "75%";
    console.log(param);
    for (j = 1; j < 152; j++) {
        if (((param.childNodes[1].src).slice(-7, -4)) == js_dex_no[j]) {
            console.log("You clicked on " + js_pokemon_name[j]);
            var poke_side1 = document.createElement('li');
            poke_side1.appendChild(document.createTextNode("#" + js_dex_no[j]));
            var poke_side2 = document.createElement('li');
            poke_side2.appendChild(document.createTextNode(js_pokemon_name[j]));
            var poke_image = document.createElement('li');
            var p_image = param.childNodes[1].cloneNode(true);
            p_image.height = "240";
            p_image.width = "240";
            poke_image.appendChild(p_image);
            var poke_side3 = document.createElement('li');
            poke_side3.appendChild(document.createTextNode("Classification : " + js_classification[j]));
            var poke_side4 = document.createElement('li');
            poke_side4.appendChild(document.createTextNode("Type : " + js_type[j]));
            var poke_side5 = document.createElement('li');
            poke_side5.appendChild(document.createTextNode("Weight : " + js_weight[j]));
            var poke_side6 = document.createElement('li');
            poke_side6.appendChild(document.createTextNode("Height : " + js_height[j]));
            var poke_side7 = document.createElement('li');
            poke_side7.appendChild(document.createTextNode("Male Ratio : " + js_male_ratio[j]));
            var poke_side8 = document.createElement('li');
            poke_side8.appendChild(document.createTextNode("Female Ratio : " + (100.00 - js_male_ratio[j])));
            var poke_side9 = document.createElement('li');
            poke_side9.appendChild(document.createTextNode("Capture Rate : " + js_capture_rate[j]));
            var side = document.getElementById("sidebar_text2");
            var vertical = document.createElement('hr');
            vertical.width = "1";
            vertical.size = "400";
            vertical.color = "black";
            vertical.style.position = "absolute";
            vertical.style.left = "300";
            vertical.style.top = "-20";
            poke_side1.style.fontFamily = "PokemonFont";
            poke_side1.style.fontSize = "40";
            poke_side2.style.fontFamily = "PokemonFont";
            poke_side2.style.fontSize = "40";
            poke_side3.style.position = "absolute";
            poke_side3.style.left = "325";
            poke_side3.style.top = "110";
            poke_side4.style.position = "absolute";
            poke_side4.style.left = "325";
            poke_side4.style.top = "0";
            poke_side5.style.position = "absolute";
            poke_side5.style.top = "230";
            poke_side5.style.left = "325";
            poke_side6.style.position = "absolute";
            poke_side6.style.top = "320";
            poke_side6.style.left = "325";
            poke_side7.style.position = "absolute";
            poke_side7.style.top = "0";
            poke_side7.style.left = "650";
            poke_side8.style.position = "absolute";
            poke_side8.style.top = "90";
            poke_side8.style.left = "650";
            poke_side9.style.position = "absolute";
            poke_side9.style.top = "180";
            poke_side9.style.left = "650";
            side.appendChild(poke_side1);
            side.appendChild(poke_side2);
            side.appendChild(vertical);
            side.appendChild(poke_image);
            side.appendChild(poke_side3);
            side.appendChild(poke_side4);
            side.appendChild(poke_side5);
            side.appendChild(poke_side6);
            side.appendChild(poke_side7);
            side.appendChild(poke_side8);
            side.appendChild(poke_side9);
        }
    }
}
//Onlclick close sidebar2
function closeNav2() {
    document.getElementById("sidebar_text2").style.transitionDelay = "0s";
    document.getElementById("sidebar_text2").style.visibility = "hidden";
    document.getElementById("sidebar_text2").style.opacity = "0";
    document.getElementById("mySidenav2").style.height = "0";
    var side = document.getElementById("sidebar_text2");
    while (side.hasChildNodes()) {
        side.removeChild(side.lastChild);
    }
}
